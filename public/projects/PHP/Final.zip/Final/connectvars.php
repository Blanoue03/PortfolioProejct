<?php // connectvars.php
mysqli_report(MYSQLI_REPORT_OFF);
DEFINE('DB_HOST', "localhost");
DEFINE('DB_USER', "blanoue");
DEFINE('DB_PASSWORD', "1n3bq1n3bq");
DEFINE('DB_NAME', "blanouedb");
?>